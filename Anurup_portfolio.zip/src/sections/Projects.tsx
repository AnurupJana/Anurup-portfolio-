import { motion } from 'motion/react';
import { Github, ExternalLink } from 'lucide-react';
import { SectionTitle } from '../components/SectionTitle';
import { profileConfig } from '../config/profileConfig';

export const Projects = () => {
  return (
    <section id="projects" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionTitle subtitle="Some of my recent work">Featured Projects</SectionTitle>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {profileConfig.projects.map((project, index) => (
            <motion.div
              key={project.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-3xl overflow-hidden border border-zinc-100 shadow-sm hover:shadow-xl transition-all group flex flex-col"
            >
              <div className="relative aspect-video overflow-hidden">
                <img 
                  src={project.image} 
                  alt={project.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-4">
                  <a href={project.github} target="_blank" rel="noopener noreferrer" className="p-3 bg-white rounded-full text-zinc-900 hover:bg-indigo-600 hover:text-white transition-all">
                    <Github size={20} />
                  </a>
                  <a href={project.demo} target="_blank" rel="noopener noreferrer" className="p-3 bg-white rounded-full text-zinc-900 hover:bg-indigo-600 hover:text-white transition-all">
                    <ExternalLink size={20} />
                  </a>
                </div>
              </div>
              
              <div className="p-6 flex-1 flex flex-col">
                <div className="flex flex-wrap gap-2 mb-4">
                  {project.tech.map(t => (
                    <span key={t} className="px-3 py-1 bg-zinc-100 text-zinc-600 text-xs font-medium rounded-full">
                      {t}
                    </span>
                  ))}
                </div>
                <h3 className="text-xl font-bold text-zinc-900 mb-2">{project.title}</h3>
                <p className="text-zinc-600 text-sm leading-relaxed mb-6 flex-1">
                  {project.description}
                </p>
                
                <div className="flex items-center gap-4 pt-4 border-t border-zinc-50">
                  <a href={project.demo} target="_blank" rel="noopener noreferrer" className="text-indigo-600 font-bold text-sm flex items-center gap-1.5 hover:underline">
                    Live Demo <ExternalLink size={14} />
                  </a>
                  <a href={project.github} target="_blank" rel="noopener noreferrer" className="text-zinc-500 font-bold text-sm flex items-center gap-1.5 hover:underline">
                    Source Code <Github size={14} />
                  </a>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
