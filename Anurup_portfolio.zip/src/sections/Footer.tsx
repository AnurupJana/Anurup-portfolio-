import { profileConfig } from '../config/profileConfig';

export const Footer = () => {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="py-12 bg-zinc-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-center gap-8">
          <div>
            <h2 className="text-2xl font-bold mb-2">{profileConfig.name}</h2>
            <p className="text-zinc-400 text-sm max-w-xs">
              Building the future of the web, one pixel at a time.
            </p>
          </div>
          
          <div className="flex gap-6">
            {profileConfig.socials.map((social) => (
              <a 
                key={social.name}
                href={social.url}
                className="text-zinc-400 hover:text-white transition-colors"
                title={social.name}
              >
                <social.icon size={20} />
              </a>
            ))}
          </div>
        </div>
        
        <div className="mt-12 pt-8 border-t border-zinc-800 text-center text-zinc-500 text-sm">
          <p>© {currentYear} {profileConfig.name}. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};
