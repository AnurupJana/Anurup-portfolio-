import { motion } from 'motion/react';
import { SectionTitle } from '../components/SectionTitle';
import { profileConfig } from '../config/profileConfig';

export const Skills = () => {
  return (
    <section id="skills" className="py-24 bg-zinc-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionTitle subtitle="My technical toolkit">Skills & Technologies</SectionTitle>
        
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-4 gap-6">
          {profileConfig.skills.map((skill, index) => (
            <motion.div
              key={skill.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.05 }}
              whileHover={{ y: -5 }}
              className="bg-white p-8 rounded-2xl shadow-sm border border-zinc-100 flex flex-col items-center text-center group hover:shadow-md transition-all"
            >
              <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center mb-4 group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                <skill.icon size={24} />
              </div>
              <h4 className="font-semibold text-zinc-900">{skill.name}</h4>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
