import { useState, useEffect, FormEvent } from 'react';
import { motion } from 'motion/react';
import { Send, Mail, MapPin, Phone, Edit2, Check } from 'lucide-react';
import { SectionTitle } from '../components/SectionTitle';
import { profileConfig } from '../config/profileConfig';

export const Contact = () => {
  const [isEditing, setIsEditing] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [contactInfo, setContactInfo] = useState({
    email: "anurup.jana2003@gmail.com",
    location: "5/65 Jatindas Nagar Belgharia Kolkata-700056",
    phone: "9083000514"
  });

  useEffect(() => {
    const savedContact = localStorage.getItem('portfolio_contact_info');
    if (savedContact) {
      setContactInfo(JSON.parse(savedContact));
    }
  }, []);

  const handleSave = () => {
    localStorage.setItem('portfolio_contact_info', JSON.stringify(contactInfo));
    setIsEditing(false);
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
      
      // Reset after 5 seconds
      setTimeout(() => setIsSubmitted(false), 5000);
    }, 1500);
  };

  return (
    <section id="contact" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionTitle subtitle="Let's build something amazing together">Get In Touch</SectionTitle>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-2xl font-bold text-zinc-900">Contact Information</h3>
              <button 
                onClick={() => isEditing ? handleSave() : setIsEditing(true)}
                className={`p-2 rounded-lg transition-all flex items-center gap-2 text-sm font-medium ${isEditing ? 'bg-green-100 text-green-700 hover:bg-green-200' : 'bg-indigo-50 text-indigo-600 hover:bg-indigo-100'}`}
              >
                {isEditing ? <><Check size={16} /> Save</> : <><Edit2 size={16} /> Edit Details</>}
              </button>
            </div>
            <p className="text-zinc-600 mb-8 leading-relaxed">
              I'm currently looking for new opportunities. Whether you have a question or just want to say hi, I'll try my best to get back to you!
            </p>
            
            <div className="space-y-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center">
                  <Mail size={20} />
                </div>
                <div className="flex-1">
                  <p className="text-sm text-zinc-500">Email Me</p>
                  {isEditing ? (
                    <input 
                      type="text" 
                      value={contactInfo.email}
                      onChange={(e) => setContactInfo({...contactInfo, email: e.target.value})}
                      className="w-full px-2 py-1 border border-zinc-200 rounded mt-1 outline-none focus:ring-2 focus:ring-indigo-600"
                    />
                  ) : (
                    <p className="font-semibold text-zinc-900">{contactInfo.email}</p>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center">
                  <MapPin size={20} />
                </div>
                <div className="flex-1">
                  <p className="text-sm text-zinc-500">Location</p>
                  {isEditing ? (
                    <input 
                      type="text" 
                      value={contactInfo.location}
                      onChange={(e) => setContactInfo({...contactInfo, location: e.target.value})}
                      className="w-full px-2 py-1 border border-zinc-200 rounded mt-1 outline-none focus:ring-2 focus:ring-indigo-600"
                    />
                  ) : (
                    <p className="font-semibold text-zinc-900">{contactInfo.location}</p>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center">
                  <Phone size={20} />
                </div>
                <div className="flex-1">
                  <p className="text-sm text-zinc-500">Call Me</p>
                  {isEditing ? (
                    <input 
                      type="text" 
                      value={contactInfo.phone}
                      onChange={(e) => setContactInfo({...contactInfo, phone: e.target.value})}
                      className="w-full px-2 py-1 border border-zinc-200 rounded mt-1 outline-none focus:ring-2 focus:ring-indigo-600"
                    />
                  ) : (
                    <p className="font-semibold text-zinc-900">{contactInfo.phone}</p>
                  )}
                </div>
              </div>
            </div>

            <div className="mt-10 flex gap-4">
              {profileConfig.socials.map((social) => (
                <a 
                  key={social.name}
                  href={social.url}
                  className="w-10 h-10 bg-zinc-100 text-zinc-600 rounded-lg flex items-center justify-center hover:bg-indigo-600 hover:text-white transition-all"
                  title={social.name}
                >
                  <social.icon size={18} />
                </a>
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="bg-zinc-50 p-8 rounded-3xl border border-zinc-100"
          >
            {isSubmitted ? (
              <div className="h-full flex flex-col items-center justify-center py-12 text-center">
                <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mb-6">
                  <Check size={40} />
                </div>
                <h3 className="text-2xl font-bold text-zinc-900 mb-2">Message Sent!</h3>
                <p className="text-zinc-600">Thank you for reaching out. I'll get back to you soon.</p>
              </div>
            ) : (
              <form className="space-y-6" onSubmit={handleSubmit}>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-zinc-700 mb-2">Name</label>
                    <input 
                      required
                      type="text" 
                      className="w-full px-4 py-3 bg-white border border-zinc-200 rounded-xl focus:ring-2 focus:ring-indigo-600 focus:border-transparent outline-none transition-all"
                      placeholder="John Doe"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-zinc-700 mb-2">Email</label>
                    <input 
                      required
                      type="email" 
                      className="w-full px-4 py-3 bg-white border border-zinc-200 rounded-xl focus:ring-2 focus:ring-indigo-600 focus:border-transparent outline-none transition-all"
                      placeholder="john@example.com"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-zinc-700 mb-2">Subject</label>
                  <input 
                    required
                    type="text" 
                    className="w-full px-4 py-3 bg-white border border-zinc-200 rounded-xl focus:ring-2 focus:ring-indigo-600 focus:border-transparent outline-none transition-all"
                    placeholder="Project Inquiry"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-zinc-700 mb-2">Message</label>
                  <textarea 
                    required
                    rows={4}
                    className="w-full px-4 py-3 bg-white border border-zinc-200 rounded-xl focus:ring-2 focus:ring-indigo-600 focus:border-transparent outline-none transition-all resize-none"
                    placeholder="Tell me about your project..."
                  />
                </div>
                <button 
                  disabled={isSubmitting}
                  type="submit"
                  className={`w-full py-4 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 transition-all flex items-center justify-center gap-2 shadow-lg shadow-indigo-100 disabled:opacity-70 disabled:cursor-not-allowed`}
                >
                  {isSubmitting ? 'Sending...' : 'Send Message'}
                  <Send size={18} className={isSubmitting ? 'animate-pulse' : ''} />
                </button>
              </form>
            )}
          </motion.div>
        </div>
      </div>
    </section>
  );
};
