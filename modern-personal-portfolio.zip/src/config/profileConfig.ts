import { Github, Linkedin, Mail, Code2, Briefcase, GraduationCap, User, Send, ExternalLink, Database, Brain, Cpu, Palette, LineChart } from 'lucide-react';

export const profileConfig = {
  name: "Anurup Jana",
  title: "B-Tech in Data Science (Student)",
  tagline: "Building technology that solves real-world problems and creates meaningful social impact.",
  bio: "I am Anurup Jana, a passionate Computer Science student and aspiring AI developer who enjoys building technology that solves real-world problems. I have a strong interest in Artificial Intelligence, software development, and impactful tech solutions, especially those that can benefit underserved communities.\n\nI enjoy turning innovative ideas into real-world solutions and working on projects that address practical challenges. I was also a finalist in the Smart India Hackathon (SIH), where I collaborated with a team to design impactful solutions under real-world constraints, gaining valuable experience in problem-solving, teamwork, and rapid innovation.\n\nCurrently, I am actively working on projects related to AI-based systems, gesture and face recognition, and agricultural technology, including research on AI-based disease detection in rice crops. I am also involved in tech communities, serving as a lead at Xplorica and a core team member at GDG On Campus FIEM, where I collaborate with developers and participate in hackathons and technical events.\n\nBeyond coding, I am passionate about innovation, problem solving, and building technology that creates meaningful social impact. My goal is to grow as an AI engineer and contribute to solutions that make advanced technology accessible to everyone.",
  profileImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=1000&auto=format&fit=crop",
  
  socials: [
    { name: "GitHub", url: "https://github.com", icon: Github },
    { name: "LinkedIn", url: "https://linkedin.com", icon: Linkedin },
    { name: "Email", url: "mailto:anurup.jana2003@gmail.com", icon: Mail },
  ],
  
  skills: [
    { name: "Python Programming", icon: Code2 },
    { name: "React.js Development", icon: Code2 },
    { name: "SQL (Relational Databases)", icon: Database },
    { name: "MongoDB", icon: Database },
    { name: "AI & Machine Learning", icon: Brain },
    { name: "Data Structures & Algorithms", icon: Cpu },
    { name: "Firebase Integration", icon: Database },
    { name: "IOT and AWS", icon: Cpu },
    { name: "Graphics Designing", icon: Palette },
  ],
  
  projects: [
    {
      title: "AI-Based Crop Disease Detection System",
      description: "Developed a machine learning model for crop disease identification using image datasets. Implemented data preprocessing and model optimization techniques. Improved classification accuracy through structured experimentation.",
      tech: ["Python", "TensorFlow", "OpenCV"],
      github: "https://github.com",
      demo: "https://example.com",
      image: "https://images.unsplash.com/photo-1523348837708-15d4a09cfac2?q=80&w=1000&auto=format&fit=crop"
    },
    {
      title: "Direct Farmer-to-Consumer Marketplace",
      description: "Developed a digital platform connecting farmers directly with buyers. Eliminated middlemen to improve farmer profit margins. Designed product listing, order management, and user authentication system. Implemented database management using MongoDB / SQL.",
      tech: ["React", "Node.js", "MongoDB", "Firebase"],
      github: "https://github.com",
      demo: "https://example.com",
      image: "https://images.unsplash.com/photo-1500937386664-56d1dfef3854?q=80&w=1000&auto=format&fit=crop"
    },
    {
      title: "AI-Based Resume Creation System",
      description: "Developed a smart resume builder using React.js and Python. Implemented dynamic form generation and real-time preview. Integrated AI-based content suggestions for skills and summaries. Exported resumes in PDF format.",
      tech: ["React", "Python", "Flask", "OpenAI"],
      github: "https://github.com",
      demo: "https://example.com",
      image: "https://images.unsplash.com/photo-1586281380349-632531db7ed4?q=80&w=1000&auto=format&fit=crop"
    },
    {
      title: "Stock Market Analysis Dashboard",
      description: "Used Python for data analysis. Built frontend in React with charts. Implemented indicators like EMA, RSI.",
      tech: ["Python", "React", "Pandas", "Recharts"],
      github: "https://github.com",
      demo: "https://example.com",
      image: "https://images.unsplash.com/photo-1611974714851-eb605161882b?q=80&w=1000&auto=format&fit=crop"
    }
  ],
  
  experience: [], // Removed as requested
  
  education: [
    {
      school: "Future Institute of Engineering and Management",
      degree: "B.Tech in Computer Science",
      period: "2021 - 2025",
      icon: GraduationCap
    }
  ]
};
