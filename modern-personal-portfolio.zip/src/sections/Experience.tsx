import { motion } from 'motion/react';
import { Briefcase, GraduationCap } from 'lucide-react';
import { SectionTitle } from '../components/SectionTitle';
import { profileConfig } from '../config/profileConfig';

export const Experience = () => {
  return (
    <section id="experience" className="py-24 bg-zinc-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionTitle subtitle="My professional journey">Experience & Education</SectionTitle>
        
        <div className="max-w-4xl mx-auto">
          <div className="space-y-12">
            <div>
              <h3 className="text-2xl font-bold text-zinc-900 mb-8 flex items-center gap-3">
                <span className="w-8 h-8 bg-indigo-100 text-indigo-600 rounded-lg flex items-center justify-center">
                  <Briefcase size={18} />
                </span>
                Work Experience
              </h3>
              
              <div className="space-y-8 border-l-2 border-zinc-200 ml-4 pl-8">
                {profileConfig.experience.map((exp, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.1 }}
                    className="relative"
                  >
                    <div className="absolute -left-[41px] top-0 w-4 h-4 bg-indigo-600 rounded-full border-4 border-white shadow-sm" />
                    <div className="bg-white p-6 rounded-2xl shadow-sm border border-zinc-100">
                      <span className="text-sm font-semibold text-indigo-600 mb-1 block">{exp.period}</span>
                      <h4 className="text-lg font-bold text-zinc-900">{exp.role}</h4>
                      <p className="text-zinc-500 font-medium mb-3">{exp.company}</p>
                      <p className="text-zinc-600 text-sm leading-relaxed">{exp.description}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>

            <div>
              <h3 className="text-2xl font-bold text-zinc-900 mb-8 flex items-center gap-3">
                <span className="w-8 h-8 bg-violet-100 text-violet-600 rounded-lg flex items-center justify-center">
                  <GraduationCap size={18} />
                </span>
                Education
              </h3>
              
              <div className="space-y-8 border-l-2 border-zinc-200 ml-4 pl-8">
                {profileConfig.education.map((edu, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.1 }}
                    className="relative"
                  >
                    <div className="absolute -left-[41px] top-0 w-4 h-4 bg-violet-600 rounded-full border-4 border-white shadow-sm" />
                    <div className="bg-white p-6 rounded-2xl shadow-sm border border-zinc-100">
                      <span className="text-sm font-semibold text-violet-600 mb-1 block">{edu.period}</span>
                      <h4 className="text-lg font-bold text-zinc-900">{edu.degree}</h4>
                      <p className="text-zinc-500 font-medium">{edu.school}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
