import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { SectionTitle } from '../components/SectionTitle';
import { profileConfig } from '../config/profileConfig';

export const About = () => {
  const [profileImg, setProfileImg] = useState(profileConfig.profileImage);
  const [contactInfo, setContactInfo] = useState({
    email: "anurup.jana2003@gmail.com",
    location: "West Bengal, India",
    education: "B.Tech in CS"
  });

  useEffect(() => {
    const savedImg = localStorage.getItem('portfolio_profile_img');
    if (savedImg) {
      setProfileImg(savedImg);
    }
    const savedContact = localStorage.getItem('portfolio_contact_info');
    if (savedContact) {
      const parsed = JSON.parse(savedContact);
      setContactInfo({
        email: parsed.email,
        location: parsed.location,
        education: "B.Tech in CS"
      });
    }
  }, []);

  return (
    <section id="about" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionTitle subtitle="Get to know me better">About Me</SectionTitle>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="aspect-video bg-zinc-100 rounded-2xl overflow-hidden shadow-inner flex items-center justify-center">
               <img 
                src={profileImg} 
                alt="Profile"
                className="w-full h-full object-cover opacity-80"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="absolute -bottom-6 -right-6 bg-indigo-600 text-white p-6 rounded-2xl shadow-xl hidden sm:block">
              <p className="text-xl font-bold">B-Tech in Data Science</p>
              <p className="text-sm opacity-80 uppercase tracking-wider">Student & Innovator</p>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <h3 className="text-2xl font-bold text-zinc-900 mb-6">
              I'm a developer who loves to turn complex problems into simple, beautiful solutions.
            </h3>
            <p className="text-zinc-600 leading-relaxed mb-8 whitespace-pre-line">
              {profileConfig.bio}
            </p>
            <div className="grid grid-cols-2 gap-6">
              <div>
                <h4 className="font-bold text-zinc-900 mb-2">Location</h4>
                <p className="text-zinc-600">{contactInfo.location}</p>
              </div>
              <div>
                <h4 className="font-bold text-zinc-900 mb-2">Email</h4>
                <p className="text-zinc-600">{contactInfo.email}</p>
              </div>
              <div>
                <h4 className="font-bold text-zinc-900 mb-2">Education</h4>
                <p className="text-zinc-600">{contactInfo.education}</p>
              </div>
              <div>
                <h4 className="font-bold text-zinc-900 mb-2">Availability</h4>
                <p className="text-zinc-600">Open to Projects</p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};
